# Lion Dance Club Management System

A React + Vite starter app for recording lion dance bookings, income, performer roles, salary and payment status.

## Features
- Dashboard with total orders, income, performer salary and club balance
- Performance order records: date, event, location, order price, additional money, payment status and notes
- Performer directory
- Role-based salary defaults (editable in Settings)
- Per-order salary overrides
- Manual allocation of additional money to performers or club funds
- Mark each performer's salary as paid
- CSV export for orders and payroll
- Data saved in the current browser using localStorage

## Run in GitHub Codespaces or locally
```bash
npm install
npm run dev
```
Open the forwarded Vite port (usually 5173).

Build:
```bash
npm run build
```

## Important data note
This starter stores data locally in the browser. It does not yet have user accounts, a shared cloud database, or automatic cross-device sync. Use the CSV export regularly for backups. For a club with multiple treasurers/devices, connect a backend database and authentication before relying on it for official financial records.
