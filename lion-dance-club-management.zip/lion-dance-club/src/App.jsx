import React, { useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard, ClipboardList, Users, Wallet, Settings, Plus, Search,
  MapPin, CalendarDays, CircleDollarSign, Pencil, Trash2, Download, Check,
  X, Menu, ChevronDown, Banknote, TrendingUp, ReceiptText, UserRound,
  Filter, Save, FileSpreadsheet, Building2, Drum
} from 'lucide-react';

const STORE = 'lion-dance-club-v1';
const defaultRoles = [
  { id: 'head', name: 'Lion Head', rate: 150 },
  { id: 'tail', name: 'Lion Tail', rate: 150 },
  { id: 'drum', name: 'Drummer', rate: 120 },
  { id: 'cymbals', name: 'Cymbals', rate: 100 },
  { id: 'gong', name: 'Gong', rate: 100 },
  { id: 'other', name: 'Other', rate: 80 }
];
const initial = { orders: [], performers: [], roles: defaultRoles, clubName: 'Lion Dance Club' };
const money = n => 'RM ' + Number(n || 0).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const today = () => new Date().toISOString().slice(0, 10);
const uid = () => crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());

function loadData() {
  try { return { ...initial, ...JSON.parse(localStorage.getItem(STORE) || '{}') }; }
  catch { return initial; }
}
function saveFile(name, content, type = 'text/csv;charset=utf-8;') {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = name; a.click();
  URL.revokeObjectURL(url);
}
function csv(rows) {
  return rows.map(row => row.map(v => `"${String(v ?? '').replaceAll('"', '""')}"`).join(',')).join('\n');
}
function Modal({ title, onClose, children, wide = false }) {
  return <div className="modal-backdrop" onMouseDown={e => e.target === e.currentTarget && onClose()}>
    <section className={`modal ${wide ? 'wide' : ''}`}>
      <div className="modal-head"><h2>{title}</h2><button className="icon-btn" onClick={onClose}><X size={19}/></button></div>
      {children}
    </section>
  </div>;
}

export default function App() {
  const [data, setData] = useState(loadData);
  const [page, setPage] = useState('dashboard');
  const [modal, setModal] = useState(null);
  const [query, setQuery] = useState('');
  const [month, setMonth] = useState('all');
  const [mobileNav, setMobileNav] = useState(false);
  const [toast, setToast] = useState('');

  useEffect(() => { localStorage.setItem(STORE, JSON.stringify(data)); }, [data]);
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(''), 2600);
    return () => clearTimeout(t);
  }, [toast]);

  const update = patch => setData(d => ({ ...d, ...patch }));
  const orders = data.orders || [];
  const performers = data.performers || [];
  const roles = data.roles || defaultRoles;
  const allIncome = orders.reduce((s, o) => s + Number(o.price || 0) + Number(o.extra || 0), 0);
  const allSalary = orders.reduce((s, o) => s + (o.assignments || []).reduce((a, p) => a + Number(p.salary || 0), 0) + (o.extraMode === 'manual' ? (o.extraAlloc || []).reduce((a, x) => a + Number(x.amount || 0), 0) : 0), 0);
  const clubBalance = allIncome - allSalary;
  const filteredOrders = useMemo(() => orders.filter(o => {
    const match = `${o.id} ${o.event} ${o.location} ${o.notes}`.toLowerCase().includes(query.toLowerCase());
    const monthMatch = month === 'all' || (o.date || '').slice(0, 7) === month;
    return match && monthMatch;
  }).sort((a,b) => (b.date || '').localeCompare(a.date || '')), [orders, query, month]);

  function removeOrder(id) {
    if (!confirm('Delete this order record? This cannot be undone.')) return;
    update({ orders: orders.filter(o => o.id !== id) }); setToast('Order deleted');
  }
  function exportOrders() {
    const rows = [['Order ID','Date','Event','Location','Order Price','Additional Received','Total Received','Performer Count','Total Salary','Club Balance','Payment Status']];
    orders.forEach(o => {
      const salary = (o.assignments || []).reduce((s,p) => s + Number(p.salary || 0), 0) + (o.extraMode === 'manual' ? (o.extraAlloc || []).reduce((s,x) => s + Number(x.amount || 0), 0) : 0);
      rows.push([o.orderNo, o.date, o.event, o.location, o.price, o.extra, Number(o.price||0)+Number(o.extra||0), (o.assignments||[]).length, salary, Number(o.price||0)+Number(o.extra||0)-salary, o.paymentStatus]);
    });
    saveFile('lion-dance-orders.csv', '\ufeff' + csv(rows));
  }
  function exportPayroll() {
    const rows = [['Performer','Role','Order ID','Date','Event','Salary','Paid']];
    orders.forEach(o => { (o.assignments || []).forEach(p => rows.push([p.name,p.roleName,o.orderNo,o.date,o.event,p.salary,p.paid ? 'Paid':'Unpaid'])); if (o.extraMode === 'manual') (o.extraAlloc || []).filter(x => Number(x.amount || 0) > 0).forEach(x => rows.push([x.name,'Additional money allocation',o.orderNo,o.date,o.event,x.amount,'Unpaid'])); });
    saveFile('lion-dance-payroll.csv', '\ufeff' + csv(rows));
  }

  const nav = [
    ['dashboard','Overview',LayoutDashboard], ['orders','Orders',ClipboardList],
    ['performers','Performers',Users], ['payroll','Salary & Payroll',Wallet], ['settings','Settings',Settings]
  ];
  return <div className="app-shell">
    <aside className={`sidebar ${mobileNav ? 'show' : ''}`}>
      <div className="brand"><div className="brand-mark"><Drum size={23}/></div><div><b>{data.clubName}</b><small>CLUB MANAGEMENT</small></div></div>
      <div className="nav-label">WORKSPACE</div>
      {nav.map(([id,label,Icon]) => <button key={id} className={`nav-item ${page===id?'active':''}`} onClick={() => {setPage(id);setMobileNav(false);}}>
        <Icon size={18}/><span>{label}</span>{id==='orders' && <em>{orders.length}</em>}
      </button>)}
      <div className="sidebar-bottom"><div className="mini-avatar">LD</div><div><b>Club Treasurer</b><small>Local workspace</small></div></div>
    </aside>
    <main className="main">
      <header className="topbar"><button className="icon-btn mobile-menu" onClick={()=>setMobileNav(v=>!v)}><Menu/></button><div className="crumb">Workspace <span>/</span> {nav.find(n=>n[0]===page)?.[1]}</div><div className="top-right"><span className="local-pill"><span/> Saved on this device</span><div className="top-avatar">LD</div></div></header>
      <div className="content">
        {page==='dashboard' && <Dashboard data={data} orders={orders} performers={performers} allIncome={allIncome} allSalary={allSalary} clubBalance={clubBalance} setPage={setPage} setModal={setModal}/>}
        {page==='orders' && <Orders orders={filteredOrders} query={query} setQuery={setQuery} month={month} setMonth={setMonth} setModal={setModal} removeOrder={removeOrder} exportOrders={exportOrders}/>}
        {page==='performers' && <Performers performers={performers} roles={roles} orders={orders} setModal={setModal} update={update} setToast={setToast}/>}
        {page==='payroll' && <Payroll orders={orders} performers={performers} exportPayroll={exportPayroll} update={update} setToast={setToast}/>}
        {page==='settings' && <SettingsPage data={data} update={update} setToast={setToast}/>}
      </div>
    </main>
    {modal?.type==='order' && <OrderModal order={modal.order} performers={performers} roles={roles} onClose={()=>setModal(null)} onSave={o=>{update({orders: modal.order ? orders.map(x=>x.id===o.id?o:x) : [o,...orders]});setModal(null);setToast(modal.order?'Order updated':'Order added');}}/>}
    {modal?.type==='performer' && <PerformerModal performer={modal.performer} roles={roles} onClose={()=>setModal(null)} onSave={p=>{update({performers:modal.performer?performers.map(x=>x.id===p.id?p:x):[...performers,p]});setModal(null);setToast('Performer saved');}}/>}
    {toast && <div className="toast"><Check size={17}/>{toast}</div>}
  </div>;
}

function PageHeading({eyebrow,title,desc,action}) {
  return <div className="page-heading"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1><p>{desc}</p></div>{action}</div>;
}
function Stat({label,value,sub,Icon,tone='red'}) {
  return <div className="stat-card"><div className={`stat-icon ${tone}`}><Icon size={20}/></div><div className="stat-label">{label}</div><div className="stat-value">{value}</div><div className="stat-sub">{sub}</div></div>;
}
function Dashboard({data,orders,performers,allIncome,allSalary,clubBalance,setPage,setModal}) {
  const recent=[...orders].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,5);
  const upcoming=[...orders].filter(o=>o.date>=today()).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
  return <>
    <PageHeading eyebrow="CLUB FINANCES" title="Overview" desc="A clear picture of your lion dance bookings and club finances." action={<button className="btn primary" onClick={()=>setModal({type:'order'})}><Plus size={17}/> Add new order</button>}/>
    <div className="stats-grid">
      <Stat label="Total orders" value={orders.length} sub="All recorded performances" Icon={ClipboardList}/>
      <Stat label="Total income" value={money(allIncome)} sub="Order prices + additional money" Icon={TrendingUp} tone="gold"/>
      <Stat label="Performer salaries" value={money(allSalary)} sub="Assigned salaries across orders" Icon={Users} tone="blue"/>
      <Stat label="Club balance" value={money(clubBalance)} sub="Income less performer salaries" Icon={Wallet} tone="green"/>
    </div>
    <div className="dashboard-grid">
      <section className="panel"><div className="panel-head"><div><h3>Recent orders</h3><p>Your latest performance records</p></div><button className="text-btn" onClick={()=>setPage('orders')}>View all <span>→</span></button></div>
        {recent.length===0?<Empty title="No orders recorded yet" text="Add your first lion dance performance to get started."/>:<div className="table-wrap"><table><thead><tr><th>PERFORMANCE</th><th>DATE</th><th>LOCATION</th><th>INCOME</th></tr></thead><tbody>{recent.map(o=><tr key={o.id}><td><b>{o.event||'Performance'}</b><small>{o.orderNo}</small></td><td>{o.date}</td><td><span className="location"><MapPin size={13}/>{o.location}</span></td><td className="amount">{money(Number(o.price||0)+Number(o.extra||0))}</td></tr>)}</tbody></table></div>}
      </section>
      <section className="panel"><div className="panel-head"><div><h3>Club at a glance</h3><p>Current records</p></div><div className="panel-icon"><Building2 size={18}/></div></div>
        <div className="glance-row"><span>Registered performers</span><b>{performers.length}</b></div><div className="glance-row"><span>Upcoming performances</span><b>{upcoming.length}</b></div><div className="glance-row"><span>Unpaid salary entries</span><b>{orders.reduce((s,o)=>s+(o.assignments||[]).filter(p=>!p.paid).length,0)}</b></div>
        <div className="quick-box"><div><b>Keep your records up to date</b><p>Record each booking and assign performers to calculate their pay.</p></div><button className="btn outline small" onClick={()=>setPage('performers')}>Manage team</button></div>
      </section>
    </div>
    <section className="panel upcoming-panel"><div className="panel-head"><div><h3>Upcoming performances</h3><p>Scheduled bookings from today onwards</p></div><CalendarDays size={19} className="muted-icon"/></div>
      {upcoming.length===0?<div className="empty-inline">No upcoming performances scheduled.</div>:<div className="upcoming-list">{upcoming.map(o=><div className="upcoming-item" key={o.id}><div className="date-tile"><b>{new Date(o.date+'T00:00:00').getDate()}</b><small>{new Date(o.date+'T00:00:00').toLocaleString('en',{month:'short'})}</small></div><div className="upcoming-info"><b>{o.event||'Performance'}</b><span><MapPin size={13}/>{o.location||'Location not set'}</span></div><strong>{money(Number(o.price||0)+Number(o.extra||0))}</strong></div>)}</div>}
    </section>
  </>;
}
function Empty({title,text}) { return <div className="empty"><div className="empty-icon"><ReceiptText size={22}/></div><b>{title}</b><p>{text}</p></div>; }

function Orders({orders,query,setQuery,month,setMonth,setModal,removeOrder,exportOrders}) {
  return <>
    <PageHeading eyebrow="BOOKING RECORDS" title="Orders" desc="Manage every lion dance performance, booking fee and additional payment." action={<button className="btn primary" onClick={()=>setModal({type:'order'})}><Plus size={17}/> Add new order</button>}/>
    <div className="toolbar"><div className="searchbox"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search event, location or order ID..."/></div><div className="filterbox"><Filter size={16}/><input aria-label="Filter by month" type="month" value={month==='all'?'':month} onChange={e=>setMonth(e.target.value||'all')}/>{month!=='all'&&<button className="clear-filter" onClick={()=>setMonth('all')}>Clear</button>}</div><button className="btn outline" onClick={exportOrders}><Download size={16}/> Export CSV</button></div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>All orders <span className="count">{orders.length}</span></h3><p>Each row represents one performance booking</p></div></div>
      {orders.length===0?<Empty title="No matching orders" text="Try another search or add a new performance order."/>:<div className="table-wrap"><table><thead><tr><th>ORDER / EVENT</th><th>DATE</th><th>LOCATION</th><th>ORDER PRICE</th><th>EXTRA</th><th>TOTAL RECEIVED</th><th>PERFORMERS</th><th> </th></tr></thead><tbody>{orders.map(o=>{const total=Number(o.price||0)+Number(o.extra||0);return <tr key={o.id}><td><b>{o.event||'Performance'}</b><small>{o.orderNo}</small></td><td>{o.date}</td><td><span className="location"><MapPin size={13}/>{o.location}</span></td><td>{money(o.price)}</td><td className="extra-money">{money(o.extra)}</td><td className="amount">{money(total)}</td><td>{(o.assignments||[]).length}</td><td><div className="row-actions"><button className="icon-btn" title="Edit order" onClick={()=>setModal({type:'order',order:o})}><Pencil size={16}/></button><button className="icon-btn danger" title="Delete order" onClick={()=>removeOrder(o.id)}><Trash2 size={16}/></button></div></td></tr>})}</tbody></table></div>}
    </section>
    <div className="footnote">Additional money is recorded separately and can be allocated manually in each order.</div>
  </>;
}

function Performers({performers,roles,orders,setModal,update,setToast}) {
  const [q,setQ]=useState('');
  const list=performers.filter(p=>p.name.toLowerCase().includes(q.toLowerCase()));
  function deletePerson(p) {
    if(!confirm(`Delete ${p.name}? Their existing order salary records will remain.`))return;
    update({performers:performers.filter(x=>x.id!==p.id)});setToast('Performer removed from team');
  }
  return <>
    <PageHeading eyebrow="TEAM DIRECTORY" title="Performers" desc="Manage club members and their default performance roles." action={<button className="btn primary" onClick={()=>setModal({type:'performer'})}><Plus size={17}/> Add performer</button>}/>
    <div className="toolbar"><div className="searchbox"><Search size={17}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search performer name..."/></div><div className="toolbar-note"><Users size={16}/>{performers.length} registered members</div></div>
    <div className="performer-grid">{list.map(p=>{const total=orders.reduce((s,o)=>s+(o.assignments||[]).filter(a=>a.performerId===p.id).reduce((x,a)=>x+Number(a.salary||0),0)+(o.extraMode==='manual'?(o.extraAlloc||[]).filter(a=>a.performerId===p.id).reduce((x,a)=>x+Number(a.amount||0),0):0),0);const role=roles.find(r=>r.id===p.roleId)?.name||p.roleName||'Other';return <div className="performer-card" key={p.id}><div className="performer-card-top"><div className="person-avatar">{p.name.slice(0,1).toUpperCase()}</div><div className="row-actions"><button className="icon-btn" onClick={()=>setModal({type:'performer',performer:p})}><Pencil size={16}/></button><button className="icon-btn danger" onClick={()=>deletePerson(p)}><Trash2 size={16}/></button></div></div><h3>{p.name}</h3><span className="role-chip">{role}</span><div className="performer-foot"><span>Total recorded salary</span><b>{money(total)}</b></div></div>})}</div>
    {performers.length===0&&<section className="panel"><Empty title="No performers added" text="Add your club members before assigning them to performance orders."/></section>}
  </>;
}

function Payroll({orders,performers,exportPayroll,update,setToast}) {
  const entries=orders.flatMap(o=>[...(o.assignments||[]).map((p,i)=>({...p,orderId:o.id,orderNo:o.orderNo,date:o.date,event:o.event,key:`${o.id}-${i}`})),...(o.extraMode==='manual'?(o.extraAlloc||[]).filter(x=>Number(x.amount||0)>0).map((x,i)=>({performerId:x.performerId,name:x.name,roleName:'Additional money allocation',salary:Number(x.amount||0),paid:false,orderId:o.id,orderNo:o.orderNo,date:o.date,event:o.event,key:`${o.id}-extra-${i}`,isExtra:true})):[])]);
  const total=entries.reduce((s,p)=>s+Number(p.salary||0),0), paid=entries.filter(p=>p.paid).reduce((s,p)=>s+Number(p.salary||0),0);
  function toggle(entry) {
    if (entry.isExtra) { setToast('Additional allocations are recorded as unpaid. Adjust them in the order record.'); return; }
    update({orders:orders.map(o=>o.id!==entry.orderId?o:{...o,assignments:o.assignments.map((p,i)=>`${o.id}-${i}`===entry.key?{...p,paid:!p.paid}:p)})});
    setToast(entry.paid?'Payment marked unpaid':'Payment marked as paid');
  }
  const byPerson=performers.map(p=>{const mine=entries.filter(e=>e.performerId===p.id);return {...p,total:mine.reduce((s,e)=>s+Number(e.salary||0),0),paid:mine.filter(e=>e.paid).reduce((s,e)=>s+Number(e.salary||0),0),count:mine.length};}).filter(p=>p.count);
  return <>
    <PageHeading eyebrow="PAYMENT TRACKER" title="Salary & payroll" desc="Review role-based pay, individual earnings and payment status." action={<button className="btn outline" onClick={exportPayroll}><Download size={16}/> Export payroll</button>}/>
    <div className="stats-grid payroll-stats"><Stat label="Total salary assigned" value={money(total)} sub={`${entries.length} salary entries`} Icon={Wallet}/><Stat label="Paid" value={money(paid)} sub="Marked as paid" Icon={Check} tone="green"/><Stat label="Outstanding" value={money(total-paid)} sub="Still awaiting payment" Icon={Banknote} tone="gold"/></div>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Individual salary summary</h3><p>Combined earnings across all recorded performances</p></div></div>
      {byPerson.length===0?<Empty title="No salary records yet" text="Add an order and assign performers to see payroll here."/>:<div className="table-wrap"><table><thead><tr><th>PERFORMER</th><th>PERFORMANCES</th><th>TOTAL EARNED</th><th>PAID</th><th>OUTSTANDING</th></tr></thead><tbody>{byPerson.map(p=><tr key={p.id}><td><b>{p.name}</b><small>{p.roleName||''}</small></td><td>{p.count}</td><td className="amount">{money(p.total)}</td><td className="paid-text">{money(p.paid)}</td><td className="extra-money">{money(p.total-p.paid)}</td></tr>)}</tbody></table></div>}
    </section>
    <section className="panel table-panel"><div className="panel-head"><div><h3>Payment entries</h3><p>Mark each performer's salary as paid when settled</p></div></div>
      {entries.length===0?<div className="empty-inline">No payment entries.</div>:<div className="table-wrap"><table><thead><tr><th>PERFORMER</th><th>PERFORMANCE</th><th>DATE</th><th>ROLE</th><th>SALARY</th><th>STATUS</th></tr></thead><tbody>{entries.map(e=><tr key={e.key}><td><b>{e.name}</b></td><td>{e.event}<small>{e.orderNo}</small></td><td>{e.date}</td><td>{e.roleName}</td><td className="amount">{money(e.salary)}</td><td>{e.isExtra?<span className="status-toggle">Bonus allocation</span>:<button className={`status-toggle ${e.paid?'is-paid':''}`} onClick={()=>toggle(e)}>{e.paid?<><Check size={13}/> Paid</>:<>Mark as paid</>}</button>}</td></tr>)}</tbody></table></div>}
    </section>
  </>;
}

function SettingsPage({data,update,setToast}) {
  const [clubName,setClubName]=useState(data.clubName);
  const [roles,setRoles]=useState(data.roles||defaultRoles);
  const [newRole,setNewRole]=useState('');
  const [newRate,setNewRate]=useState('');
  useEffect(()=>{setClubName(data.clubName);setRoles(data.roles||defaultRoles);},[data.clubName,data.roles]);
  function save(){update({clubName:clubName.trim()||'Lion Dance Club',roles});setToast('Settings saved');}
  return <>
    <PageHeading eyebrow="PREFERENCES" title="Settings" desc="Set your club name and default salary rates for each performance role."/>
    <div className="settings-grid"><section className="panel settings-panel"><h3>Club information</h3><p className="section-desc">This name appears in the app navigation.</p><label>Club name</label><input className="field" value={clubName} onChange={e=>setClubName(e.target.value)} placeholder="e.g. Red Dragon Lion Dance Club"/><div className="section-divider"/><div className="panel-head compact"><div><h3>Role-based salary rates</h3><p>Default rates in Malaysian Ringgit (RM) per performance.</p></div></div>
      <div className="role-rate-list">{roles.map(r=><div className="role-rate" key={r.id}><span>{r.name}</span><div className="rate-input"><span>RM</span><input type="number" min="0" step="0.01" value={r.rate} onChange={e=>setRoles(rs=>rs.map(x=>x.id===r.id?{...x,rate:e.target.value}:x))}/></div></div>)}</div>
      <div className="add-role"><input className="field" value={newRole} onChange={e=>setNewRole(e.target.value)} placeholder="New role name"/><input className="field rate-new" type="number" min="0" placeholder="Rate RM" value={newRate} onChange={e=>setNewRate(e.target.value)}/><button className="btn outline" onClick={()=>{if(!newRole.trim())return;setRoles(r=>[...r,{id:uid(),name:newRole.trim(),rate:Number(newRate)||0}]);setNewRole('');setNewRate('');}}><Plus size={16}/> Add role</button></div>
      <div className="settings-actions"><button className="btn primary" onClick={save}><Save size={16}/> Save settings</button></div>
    </section>
    <section className="panel info-panel"><div className="info-symbol"><FileSpreadsheet size={22}/></div><h3>Your data stays on this device</h3><p>This starter version saves records in this browser using local storage. Export your orders and payroll CSV regularly as a backup.</p><div className="info-line"><Check size={15}/> No account required</div><div className="info-line"><Check size={15}/> Exportable CSV records</div><div className="info-line"><Check size={15}/> Role-based salary defaults</div></section></div>
  </>;
}

function OrderModal({order,performers,roles,onClose,onSave}) {
  const [form,setForm]=useState(()=>order?{...order,assignments:order.assignments||[]}:{id:uid(),orderNo:`LD-${String(Date.now()).slice(-6)}`,date:today(),event:'',location:'',price:'',extra:'0',notes:'',paymentStatus:'Received',assignments:[]});
  const [extraMode,setExtraMode]=useState(order?.extraMode||'club');
  const [extraAlloc,setExtraAlloc]=useState(order?.extraAlloc||[]);
  const [selected,setSelected]=useState('');
  const [roleId,setRoleId]=useState(roles[0]?.id||'');
  const [customSalary,setCustomSalary]=useState('');
  const [customRole,setCustomRole]=useState('');
  const set=(k,v)=>setForm(f=>({...f,[k]:v}));
  const totalSalary=form.assignments.reduce((s,p)=>s+Number(p.salary||0),0)+ (extraMode==='manual'?extraAlloc.reduce((s,a)=>s+Number(a.amount||0),0):0);
  const total=Number(form.price||0)+Number(form.extra||0);
  const allocated=extraAlloc.reduce((s,a)=>s+Number(a.amount||0),0);
  function addAssignment() {
    const person=performers.find(p=>p.id===selected); const role=roles.find(r=>r.id===roleId);
    if(!person){alert('Please select a performer.');return;}
    if(form.assignments.some(a=>a.performerId===person.id)){alert('This performer is already assigned to this order.');return;}
    const roleName=customRole.trim()||role?.name||person.roleName||'Other';
    const rate=customSalary!==''?Number(customSalary):Number(role?.rate??0);
    set('assignments',[...form.assignments,{performerId:person.id,name:person.name,roleName,salary:rate,paid:false}]);
    setSelected('');setCustomSalary('');setCustomRole('');
  }
  function updateAssignment(i,patch){set('assignments',form.assignments.map((a,n)=>n===i?{...a,...patch}:a));}
  function save() {
    if(!form.date||!form.event.trim()||!form.location.trim()){alert('Please fill in the date, event name and location.');return;}
    if(Number(form.price)<0||Number(form.extra)<0){alert('Amounts cannot be negative.');return;}
    onSave({...form,extraMode,extraAlloc});
  }
  return <Modal title={order?'Edit performance order':'Add performance order'} onClose={onClose} wide>
    <div className="form-grid">
      <div className="field-group"><label>Order ID</label><input className="field" value={form.orderNo} onChange={e=>set('orderNo',e.target.value)}/></div>
      <div className="field-group"><label>Performance date *</label><input className="field" type="date" value={form.date} onChange={e=>set('date',e.target.value)}/></div>
      <div className="field-group span-2"><label>Event / customer name *</label><input className="field" value={form.event} onChange={e=>set('event',e.target.value)} placeholder="e.g. Shop grand opening"/></div>
      <div className="field-group span-2"><label>Performance location *</label><input className="field" value={form.location} onChange={e=>set('location',e.target.value)} placeholder="Venue, area or full address"/></div>
      <div className="field-group"><label>Order price (RM)</label><input className="field" type="number" min="0" step="0.01" value={form.price} onChange={e=>set('price',e.target.value)} placeholder="0.00"/></div>
      <div className="field-group"><label>Additional money received (RM)</label><input className="field" type="number" min="0" step="0.01" value={form.extra} onChange={e=>set('extra',e.target.value)} placeholder="0.00"/></div>
      <div className="field-group span-2"><label>Payment status</label><select className="field" value={form.paymentStatus} onChange={e=>set('paymentStatus',e.target.value)}><option>Received</option><option>Partially received</option><option>Pending</option></select></div>
      <div className="field-group span-2"><label>Notes (optional)</label><textarea className="field" rows="2" value={form.notes} onChange={e=>set('notes',e.target.value)} placeholder="Contact person, event details, other notes..."/></div>
    </div>
    <div className="assignment-section"><div className="section-title"><div><h3>Performers & role-based salary</h3><p>Choose a member and role. The default rate comes from Settings and can be adjusted for this order.</p></div><span className="count">{form.assignments.length} assigned</span></div>
      {performers.length===0?<div className="hint-box">No performers in your directory yet. Close this window and add performers first.</div>:<div className="assignment-add"><select className="field" value={selected} onChange={e=>setSelected(e.target.value)}><option value="">Select performer</option>{performers.filter(p=>!form.assignments.some(a=>a.performerId===p.id)).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select><select className="field" value={roleId} onChange={e=>setRoleId(e.target.value)}>{roles.map(r=><option key={r.id} value={r.id}>{r.name} · {money(r.rate)}</option>)}</select><input className="field" type="number" min="0" placeholder="Custom salary (optional)" value={customSalary} onChange={e=>setCustomSalary(e.target.value)}/><input className="field" placeholder="Custom role (optional)" value={customRole} onChange={e=>setCustomRole(e.target.value)}/><button className="btn outline" onClick={addAssignment}><Plus size={16}/> Add</button></div>}
      {form.assignments.length>0&&<div className="assignment-list">{form.assignments.map((a,i)=><div className="assignment-row" key={`${a.performerId}-${i}`}><div className="assignment-person"><div className="tiny-avatar">{a.name.slice(0,1)}</div><div><b>{a.name}</b><small>{a.roleName}</small></div></div><label className="salary-edit"><span>Salary RM</span><input type="number" min="0" value={a.salary} onChange={e=>updateAssignment(i,{salary:e.target.value})}/></label><label className="paid-check"><input type="checkbox" checked={!!a.paid} onChange={e=>updateAssignment(i,{paid:e.target.checked})}/> Paid</label><button className="icon-btn danger" onClick={()=>set('assignments',form.assignments.filter((_,n)=>n!==i))}><Trash2 size={16}/></button></div>)}</div>}
      <div className="salary-total"><span>Total performer salary</span><b>{money(totalSalary)}</b></div>
    </div>
    <div className="assignment-section extra-allocation"><div className="section-title"><div><h3>Additional money allocation</h3><p>Manual handling: decide how much, if any, goes to members or stays in club funds.</p></div></div>
      <div className="allocation-mode"><label><input type="radio" checked={extraMode==='club'} onChange={()=>setExtraMode('club')}/> Keep all in club funds</label><label><input type="radio" checked={extraMode==='manual'} onChange={()=>setExtraMode('manual')}/> Manually allocate</label></div>
      {extraMode==='manual'&&<><div className="allocation-list">{form.assignments.map((a,i)=>{const item=extraAlloc.find(x=>x.performerId===a.performerId);return <label className="allocation-row" key={a.performerId}><span>{a.name}</span><div className="rate-input"><span>RM</span><input type="number" min="0" value={item?.amount??0} onChange={e=>setExtraAlloc(xs=>[...xs.filter(x=>x.performerId!==a.performerId),{performerId:a.performerId,name:a.name,amount:e.target.value}])}/></div></label>;})}</div><div className="allocation-summary"><span>Allocated to performers: <b>{money(allocated)}</b></span><span>Remaining in club: <b>{money(Number(form.extra||0)-allocated)}</b></span></div>{allocated>Number(form.extra||0)&&<div className="warning-text">Allocated additional money is higher than the additional money received.</div>}</>}
    </div>
    <div className="modal-summary"><div><span>Total received</span><b>{money(total)}</b></div><div><span>Performer salaries</span><b>{money(totalSalary)}</b></div><div><span>Club balance after salary</span><b>{money(total-totalSalary)}</b></div></div>
    <div className="modal-actions"><button className="btn outline" onClick={onClose}>Cancel</button><button className="btn primary" onClick={save}><Save size={16}/> Save order</button></div>
  </Modal>;
}

function PerformerModal({performer,roles,onClose,onSave}) {
  const [name,setName]=useState(performer?.name||'');
  const [roleId,setRoleId]=useState(performer?.roleId||roles[0]?.id||'');
  const [phone,setPhone]=useState(performer?.phone||'');
  function save(){if(!name.trim()){alert('Please enter the performer name.');return;}const role=roles.find(r=>r.id===roleId);onSave({id:performer?.id||uid(),name:name.trim(),roleId,roleName:role?.name||'Other',phone});}
  return <Modal title={performer?'Edit performer':'Add performer'} onClose={onClose}>
    <div className="field-group"><label>Performer name *</label><input autoFocus className="field" value={name} onChange={e=>setName(e.target.value)} placeholder="Full name"/></div>
    <div className="field-group spaced"><label>Default performance role</label><select className="field" value={roleId} onChange={e=>setRoleId(e.target.value)}>{roles.map(r=><option key={r.id} value={r.id}>{r.name} · {money(r.rate)}</option>)}</select></div>
    <div className="field-group spaced"><label>Phone number (optional)</label><input className="field" value={phone} onChange={e=>setPhone(e.target.value)} placeholder="Contact number"/></div>
    <div className="modal-actions"><button className="btn outline" onClick={onClose}>Cancel</button><button className="btn primary" onClick={save}><Save size={16}/> Save performer</button></div>
  </Modal>;
}